<?xml version="1.0" encoding="UTF-8"?>
<jmeterTestPlan version="1.2" properties="5.0" jmeter="5.5">
  <hashTree>
    <TestPlan guiclass="TestPlanGui" testclass="TestPlan" testname="测试计划" enabled="true">
      <stringProp name="TestPlan.comments"></stringProp>
      <boolProp name="TestPlan.functional_mode">false</boolProp>
      <boolProp name="TestPlan.tearDown_on_shutdown">true</boolProp>
      <boolProp name="TestPlan.serialize_threadgroups">false</boolProp>
      <elementProp name="TestPlan.user_defined_variables" elementType="Arguments" guiclass="ArgumentsPanel" testclass="Arguments" testname="用户定义的变量" enabled="true">
        <collectionProp name="Arguments.arguments"/>
      </elementProp>
      <stringProp name="TestPlan.user_define_classpath">D:\JAVA\JDK\jre\lib\ext\goldilocks8.jar,D:\微信文件\WeChat Files\wxid_itirn2nui8xv21\FileStorage\File\2021-12\jmeterziliao\apache-jmeter-5.2\apache-jmeter-5.2\lib\goldilocks8.jar</stringProp>
    </TestPlan>
    <hashTree>
      <ThreadGroup guiclass="ThreadGroupGui" testclass="ThreadGroup" testname="行为分析埋点压测" enabled="true">
        <stringProp name="ThreadGroup.on_sample_error">stoptestnow</stringProp>
        <elementProp name="ThreadGroup.main_controller" elementType="LoopController" guiclass="LoopControlPanel" testclass="LoopController" testname="循环控制器" enabled="true">
          <boolProp name="LoopController.continue_forever">false</boolProp>
          <stringProp name="LoopController.loops">1</stringProp>
        </elementProp>
        <stringProp name="ThreadGroup.num_threads">1</stringProp>
        <stringProp name="ThreadGroup.ramp_time">1</stringProp>
        <boolProp name="ThreadGroup.scheduler">false</boolProp>
        <stringProp name="ThreadGroup.duration"></stringProp>
        <stringProp name="ThreadGroup.delay"></stringProp>
        <boolProp name="ThreadGroup.same_user_on_next_iteration">true</boolProp>
      </ThreadGroup>
      <hashTree>
        <Arguments guiclass="ArgumentsPanel" testclass="Arguments" testname="用户定义的变量" enabled="true">
          <collectionProp name="Arguments.arguments">
            <elementProp name="SDK_value1" elementType="Argument">
              <stringProp name="Argument.name">SDK_value1</stringProp>
              <stringProp name="Argument.value">&quot;iOS&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="SDK_value2" elementType="Argument">
              <stringProp name="Argument.name">SDK_value2</stringProp>
              <stringProp name="Argument.value">&quot;Android&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="MODEL_value1" elementType="Argument">
              <stringProp name="Argument.name">MODEL_value1</stringProp>
              <stringProp name="Argument.value">&quot;iPhone7,2&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="MODEL_value2" elementType="Argument">
              <stringProp name="Argument.name">MODEL_value2</stringProp>
              <stringProp name="Argument.value">&quot;iPhone7,1&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="MODEL_value3" elementType="Argument">
              <stringProp name="Argument.name">MODEL_value3</stringProp>
              <stringProp name="Argument.value">&quot;iPhone8,1&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="MODEL_value4" elementType="Argument">
              <stringProp name="Argument.name">MODEL_value4</stringProp>
              <stringProp name="Argument.value">&quot;iPhone8,2&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="MODEL_value5" elementType="Argument">
              <stringProp name="Argument.name">MODEL_value5</stringProp>
              <stringProp name="Argument.value">&quot;iPhone8,3&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="MODEL_value5" elementType="Argument">
              <stringProp name="Argument.name">MODEL_value5</stringProp>
              <stringProp name="Argument.value">&quot;iPhone8,4&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="MODEL_value6" elementType="Argument">
              <stringProp name="Argument.name">MODEL_value6</stringProp>
              <stringProp name="Argument.value">&quot;iPhone9,1&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="MODEL_value7" elementType="Argument">
              <stringProp name="Argument.name">MODEL_value7</stringProp>
              <stringProp name="Argument.value">&quot;iPhone9,2&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="MODEL_value8" elementType="Argument">
              <stringProp name="Argument.name">MODEL_value8</stringProp>
              <stringProp name="Argument.value">&quot;iPhone9,4&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="MODEL_value9" elementType="Argument">
              <stringProp name="Argument.name">MODEL_value9</stringProp>
              <stringProp name="Argument.value">&quot;iPhone10,1&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="OS_VERSION_value1" elementType="Argument">
              <stringProp name="Argument.name">OS_VERSION_value1</stringProp>
              <stringProp name="Argument.value">&quot;12.5.1&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="OS_VERSION_value2" elementType="Argument">
              <stringProp name="Argument.name">OS_VERSION_value2</stringProp>
              <stringProp name="Argument.value">&quot;12.5.2&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="OS_VERSION_value3" elementType="Argument">
              <stringProp name="Argument.name">OS_VERSION_value3</stringProp>
              <stringProp name="Argument.value">&quot;12.5.3&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="OS_VERSION_value4" elementType="Argument">
              <stringProp name="Argument.name">OS_VERSION_value4</stringProp>
              <stringProp name="Argument.value">&quot;12.5.4&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="OS_VERSION_value5" elementType="Argument">
              <stringProp name="Argument.name">OS_VERSION_value5</stringProp>
              <stringProp name="Argument.value">&quot;13.0&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="OS_VERSION_value6" elementType="Argument">
              <stringProp name="Argument.name">OS_VERSION_value6</stringProp>
              <stringProp name="Argument.value">&quot;13.0.1&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="OS_VERSION_value7" elementType="Argument">
              <stringProp name="Argument.name">OS_VERSION_value7</stringProp>
              <stringProp name="Argument.value">&quot;14.1&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="NETWORK_value1" elementType="Argument">
              <stringProp name="Argument.name">NETWORK_value1</stringProp>
              <stringProp name="Argument.value">&quot;WIFI&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="NETWORK_value2" elementType="Argument">
              <stringProp name="Argument.name">NETWORK_value2</stringProp>
              <stringProp name="Argument.value">&quot;2G&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="NETWORK_value3" elementType="Argument">
              <stringProp name="Argument.name">NETWORK_value3</stringProp>
              <stringProp name="Argument.value">&quot;3G&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="NETWORK_value4" elementType="Argument">
              <stringProp name="Argument.name">NETWORK_value4</stringProp>
              <stringProp name="Argument.value">&quot;4G&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="CARRIER_NAME_value1" elementType="Argument">
              <stringProp name="Argument.name">CARRIER_NAME_value1</stringProp>
              <stringProp name="Argument.value">&quot;中国联通&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="CARRIER_NAME_value2" elementType="Argument">
              <stringProp name="Argument.name">CARRIER_NAME_value2</stringProp>
              <stringProp name="Argument.value">&quot;中国移动&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="CARRIER_NAME_value3" elementType="Argument">
              <stringProp name="Argument.name">CARRIER_NAME_value3</stringProp>
              <stringProp name="Argument.value">&quot;中国电信&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="iOS_SCREEN_SIZE_value1" elementType="Argument">
              <stringProp name="Argument.name">iOS_SCREEN_SIZE_value1</stringProp>
              <stringProp name="Argument.value">&quot;1136*640&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="iOS_SCREEN_SIZE_value2" elementType="Argument">
              <stringProp name="Argument.name">iOS_SCREEN_SIZE_value2</stringProp>
              <stringProp name="Argument.value">&quot;1334*750&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="iOS_SCREEN_SIZE_value3" elementType="Argument">
              <stringProp name="Argument.name">iOS_SCREEN_SIZE_value3</stringProp>
              <stringProp name="Argument.value">&quot;1920*1080&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="iOS_SCREEN_SIZE_value4" elementType="Argument">
              <stringProp name="Argument.name">iOS_SCREEN_SIZE_value4</stringProp>
              <stringProp name="Argument.value">&quot;2436*1125&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="iOS_SCREEN_SIZE_value5" elementType="Argument">
              <stringProp name="Argument.name">iOS_SCREEN_SIZE_value5</stringProp>
              <stringProp name="Argument.value">&quot;1792*828&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="iOS_SCREEN_SIZE_value6" elementType="Argument">
              <stringProp name="Argument.name">iOS_SCREEN_SIZE_value6</stringProp>
              <stringProp name="Argument.value">&quot;2532*1170&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="iOS_SCREEN_SIZE_value7" elementType="Argument">
              <stringProp name="Argument.name">iOS_SCREEN_SIZE_value7</stringProp>
              <stringProp name="Argument.value">&quot;2340*1080&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="iOS_SCREEN_SIZE_value8" elementType="Argument">
              <stringProp name="Argument.name">iOS_SCREEN_SIZE_value8</stringProp>
              <stringProp name="Argument.value">&quot;2688*1242&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="iOS_SCREEN_SIZE_value9" elementType="Argument">
              <stringProp name="Argument.name">iOS_SCREEN_SIZE_value9</stringProp>
              <stringProp name="Argument.value">&quot;2778*1284&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="ANDROID_SCREEN_SIZE_value1" elementType="Argument">
              <stringProp name="Argument.name">ANDROID_SCREEN_SIZE_value1</stringProp>
              <stringProp name="Argument.value">&quot;2560*1440&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="ANDROID_SCREEN_SIZE_value2" elementType="Argument">
              <stringProp name="Argument.name">ANDROID_SCREEN_SIZE_value2</stringProp>
              <stringProp name="Argument.value">&quot;1920*1080&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="ANDROID_SCREEN_SIZE_value3" elementType="Argument">
              <stringProp name="Argument.name">ANDROID_SCREEN_SIZE_value3</stringProp>
              <stringProp name="Argument.value">&quot;1280*720&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="ANDROID_SCREEN_SIZE_value4" elementType="Argument">
              <stringProp name="Argument.name">ANDROID_SCREEN_SIZE_value4</stringProp>
              <stringProp name="Argument.value">&quot;2960*1440&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="ANDROID_SCREEN_SIZE_value5" elementType="Argument">
              <stringProp name="Argument.name">ANDROID_SCREEN_SIZE_value5</stringProp>
              <stringProp name="Argument.value">&quot;2040*1080&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="ANDROID_OS_VERSION_value1" elementType="Argument">
              <stringProp name="Argument.name">ANDROID_OS_VERSION_value1</stringProp>
              <stringProp name="Argument.value">&quot;android12&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="ANDROID_OS_VERSION_value2" elementType="Argument">
              <stringProp name="Argument.name">ANDROID_OS_VERSION_value2</stringProp>
              <stringProp name="Argument.value">&quot;android11&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="ADNROID_OS_VERSION_value3" elementType="Argument">
              <stringProp name="Argument.name">ADNROID_OS_VERSION_value3</stringProp>
              <stringProp name="Argument.value">&quot;android10&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="CHANNEL_value1" elementType="Argument">
              <stringProp name="Argument.name">CHANNEL_value1</stringProp>
              <stringProp name="Argument.value">&quot;小米应用商店&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="CHANNEL_value2" elementType="Argument">
              <stringProp name="Argument.name">CHANNEL_value2</stringProp>
              <stringProp name="Argument.value">&quot;华为应用商店&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="CHANNEL_value3" elementType="Argument">
              <stringProp name="Argument.name">CHANNEL_value3</stringProp>
              <stringProp name="Argument.value">&quot;vivo应用商店&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="CHANNEL_value4" elementType="Argument">
              <stringProp name="Argument.name">CHANNEL_value4</stringProp>
              <stringProp name="Argument.value">&quot;play商店&quot;</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="STATUS_CODE_value1" elementType="Argument">
              <stringProp name="Argument.name">STATUS_CODE_value1</stringProp>
              <stringProp name="Argument.value">200</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="STATUS_CODE_value2" elementType="Argument">
              <stringProp name="Argument.name">STATUS_CODE_value2</stringProp>
              <stringProp name="Argument.value">404</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="STATUS_CODE_value3" elementType="Argument">
              <stringProp name="Argument.name">STATUS_CODE_value3</stringProp>
              <stringProp name="Argument.value">503</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
            <elementProp name="STATUS_CODE_value4" elementType="Argument">
              <stringProp name="Argument.name">STATUS_CODE_value4</stringProp>
              <stringProp name="Argument.value">501</stringProp>
              <stringProp name="Argument.metadata">=</stringProp>
            </elementProp>
          </collectionProp>
        </Arguments>
        <hashTree/>
        <LoopController guiclass="LoopControlPanel" testclass="LoopController" testname="循环控制器" enabled="true">
          <boolProp name="LoopController.continue_forever">true</boolProp>
          <stringProp name="LoopController.loops">1</stringProp>
        </LoopController>
        <hashTree>
          <CSVDataSet guiclass="TestBeanGUI" testclass="CSVDataSet" testname="CSV 数据文件设置" enabled="false">
            <stringProp name="filename">/Users/rechael/Desktop/行为分析压测/devideid.csv</stringProp>
            <stringProp name="fileEncoding">UTF-8</stringProp>
            <stringProp name="variableNames">temple_device_id</stringProp>
            <boolProp name="ignoreFirstLine">false</boolProp>
            <stringProp name="delimiter"></stringProp>
            <boolProp name="quotedData">false</boolProp>
            <boolProp name="recycle">true</boolProp>
            <boolProp name="stopThread">false</boolProp>
            <stringProp name="shareMode">shareMode.all</stringProp>
          </CSVDataSet>
          <hashTree/>
          <BeanShellSampler guiclass="BeanShellSamplerGui" testclass="BeanShellSampler" testname="总的变量变量定义" enabled="true">
            <stringProp name="BeanShellSampler.query">vars.put(&quot;XWFX_IP&quot;,&quot;www.csiihf.tech&quot;);//行为分析服务器ip地址
vars.put(&quot;XWFX_PORT&quot;,&quot;55554&quot;);//行为分析服务器端口号

vars.put(&quot;APP_CODE&quot;,&quot;13&quot;);
vars.put(&quot;UID&quot;,&quot;${__UUID}&quot;);
vars.put(&quot;DEVICE_ID&quot;,&quot;${__UUID}&quot;);
vars.put(&quot;IDFA&quot;,&quot;${__UUID}&quot;);
vars.put(&quot;IDFV&quot;,&quot;${__UUID}&quot;);


vars.put(&quot;SDK&quot;,${__RandomFromMultipleVars(SDK_value1|SDK_value2,)});
vars.put(&quot;SDK_VERSION&quot;,&quot;1.0.0&quot;);

if(vars.get(&quot;SDK&quot;).contains(&quot;iOS&quot;)){
	String ios_screen_size = ${__RandomFromMultipleVars(iOS_SCREEN_SIZE_value1|iOS_SCREEN_SIZE_value2|iOS_SCREEN_SIZE_value3|iOS_SCREEN_SIZE_value4|iOS_SCREEN_SIZE_value5|iOS_SCREEN_SIZE_value6|iOS_SCREEN_SIZE_value7|iOS_SCREEN_SIZE_value8|iOS_SCREEN_SIZE_value9,)};
	String[] result= ios_screen_size.split(&quot;\\\\*&quot;);
	vars.putObject(&quot;SCREEN_WIDTH&quot;,Integer.valueOf(result[0]));
	vars.putObject(&quot;SCREEN_HEIGHT&quot;,Integer.valueOf(result[1]));
	vars.put(&quot;MODEL&quot;,${__RandomFromMultipleVars(MODEL_value1|MODEL_value2|MODEL_value3|MODEL_value4|MODEL_value5|MODEL_value6|MODEL_value7|MODEL_value8|MODEL_value9,)});
	vars.put(&quot;OS_VERSION&quot;,${__RandomFromMultipleVars(OS_VERSION_value1|OS_VERSION_value2|OS_VERSION_value3|OS_VERSION_value4|OS_VERSION_value5|OS_VERSION_value6|OS_VERSION_value7,)});
	vars.put(&quot;MANUFACTURER&quot;,&quot;Apple&quot;);
	vars.put(&quot;BRAND&quot;,&quot;Apple&quot;);
	vars.put(&quot;CHANNEL&quot;,&quot;Apple Store&quot;);
	vars.put(&quot;PLATFORM&quot;,&quot;iOS&quot;);
	vars.put(&quot;OS&quot;,&quot;iOS&quot;);
	vars.put(&quot;APP_VERSION&quot;,&quot;1.0.8&quot;);
}else{
	String android_screen_size = ${__RandomFromMultipleVars(ANDROID_SCREEN_SIZE_value1|ANDROID_SCREEN_SIZE_value2|ANDROID_SCREEN_SIZE_value3|ANDROID_SCREEN_SIZE_value4|ANDROID_SCREEN_SIZE_value5,)};
	String[] result= android_screen_size.split(&quot;\\\\*&quot;);
	vars.putObject(&quot;SCREEN_WIDTH&quot;,Integer.valueOf(result[0]));
	vars.putObject(&quot;SCREEN_HEIGHT&quot;,Integer.valueOf(result[1]));
	vars.put(&quot;MODEL&quot;,&quot;ANL-100&quot;);
	vars.put(&quot;OS_VERSION&quot;,${__RandomFromMultipleVars(ANDROID_OS_VERSION_value1|ANDROID_OS_VERSION_value2|ANDROID_OS_VERSION_value3,)});
	vars.put(&quot;MANUFACTURER&quot;,&quot;HUAWEI&quot;);
	vars.put(&quot;BRAND&quot;,&quot;华为&quot;);

	vars.put(&quot;CHANNEL&quot;,${__RandomFromMultipleVars(CHANNEL_value1|CHANNEL_value2|CHANNEL_value3|CHANNEL_value4,)});
	vars.put(&quot;PLATFORM&quot;,&quot;Android&quot;);
	vars.put(&quot;OS&quot;,&quot;Android&quot;);
	vars.put(&quot;APP_VERSION&quot;,&quot;1.0.4&quot;);
}
vars.put(&quot;NETWORK&quot;,${__RandomFromMultipleVars(NETWORK_value1|NETWORK_value2|NETWORK_value3|NETWORK_value4,)});
vars.put(&quot;CARRIER_NAME&quot;,${__RandomFromMultipleVars(CARRIER_NAME_value1|CARRIER_NAME_value2|CARRIER_NAME_value3,)});

vars.put(&quot;SESSION_ID&quot;,&quot;${__RandomString(16,1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ,)}&quot;);

vars.putObject(&quot;IS_FIRST_DAY&quot;,true);
vars.putObject(&quot;STARTUP_FINISH_DUR&quot;,${__Random(899,10000,)});

vars.putObject(&quot;COUNTRY&quot;,&quot;中国&quot;);
vars.putObject(&quot;PROVINCE&quot;,&quot;安徽省&quot;);
vars.putObject(&quot;CITY&quot;,&quot;合肥市&quot;);

vars.putObject(&quot;END_DUR&quot;,${__Random(1000,100000,)});

if(vars.get(&quot;SDK&quot;).contains(&quot;iOS&quot;)){
	vars.put(&quot;CRASH_DATA&quot;,&quot;{\\\\\&quot;crash_stack\\\\\&quot;:[\\\\\&quot;0CoreFoundation0x00000001aedff198&lt;redacted&gt;+252\\\\\&quot;,\\\\\&quot;1libobjc.A.dylib0x00000001adfd79f8objc_exception_throw+56\\\\\&quot;,\\\\\&quot;2CoreFoundation0x00000001aed78bec_CFArgv+0\\\\\&quot;,\\\\\&quot;3CoreFoundation0x00000001aed0a48c&lt;redacted&gt;+0\\\\\&quot;,\\\\\&quot;4CSIIBuryPointSDKDemo0x00000001007a5a28-[ViewControllertest3BtnAction]+128\\\\\&quot;,\\\\\&quot;5UIKitCore0x00000001db7d8300&lt;redacted&gt;+96\\\\\&quot;,\\\\\&quot;6CSIIBuryPointSDK0x0000000100868ff0CSIISwizzledMethodUIApplicationSendActionToFromForEvent+360\\\\\&quot;,\\\\\&quot;7UIKitCore0x00000001db281424&lt;redacted&gt;+80\\\\\&quot;,\\\\\&quot;8UIKitCore0x00000001db281744&lt;redacted&gt;+440\\\\\&quot;,\\\\\&quot;9UIKitCore0x00000001db2807b0&lt;redacted&gt;+568\\\\\&quot;,\\\\\&quot;10UIKitCore0x00000001db80f5c4&lt;redacted&gt;+2108\\\\\&quot;,\\\\\&quot;11UIKitCore0x00000001db8107ec&lt;redacted&gt;+3140\\\\\&quot;,\\\\\&quot;12UIKitCore0x00000001db7f085c&lt;redacted&gt;+340\\\\\&quot;,\\\\\&quot;13UIKitCore0x00000001db8b69d4&lt;redacted&gt;+1768\\\\\&quot;,\\\\\&quot;14UIKitCore0x00000001db8b9100&lt;redacted&gt;+4828\\\\\&quot;,\\\\\&quot;15UIKitCore0x00000001db8b2330&lt;redacted&gt;+152\\\\\&quot;,\\\\\&quot;16CoreFoundation0x00000001aed90f1c&lt;redacted&gt;+24\\\\\&quot;,\\\\\&quot;17CoreFoundation0x00000001aed90e9c&lt;redacted&gt;+88\\\\\&quot;,\\\\\&quot;18CoreFoundation0x00000001aed90784&lt;redacted&gt;+176\\\\\&quot;,\\\\\&quot;19CoreFoundation0x00000001aed8b6c0&lt;redacted&gt;+1004\\\\\&quot;,\\\\\&quot;20CoreFoundation0x00000001aed8afb4CFRunLoopRunSpecific+436\\\\\&quot;,\\\\\&quot;21GraphicsServices0x00000001b0f8c79cGSEventRunModal+104\\\\\&quot;,\\\\\&quot;22UIKitCore0x00000001db7d6c38UIApplicationMain+212\\\\\&quot;,\\\\\&quot;23CSIIBuryPointSDKDemo0x00000001007a64bcmain+128\\\\\&quot;,\\\\\&quot;24libdyld.dylib0x00000001ae84e8e0&lt;redacted&gt;+4\\\\\&quot;],\\\\\&quot;crash_name\\\\\&quot;:\\\\\&quot;NSRangeException\\\\\&quot;,\\\\\&quot;crash_binary\\\\\&quot;:[{\\\\\&quot;loadAddress\\\\\&quot;:4294967296,\\\\\&quot;imageName\\\\\&quot;:\\\\\&quot;\\\\/var\\\\/containers\\\\/Bundle\\\\/Application\\\\/0B726DB0-346A-4798-A79F-E58B08DD0C3C\\\\/CSIIBuryPointSDKDemo.app\\\\/CSIIBuryPointSDKDemo\\\\\&quot;,\\\\\&quot;loadEndAddress\\\\\&quot;:4295000063,\\\\\&quot;uuid\\\\\&quot;:\\\\\&quot;5AB14925-A77A-3F62-87C8-AD8E152F7FF7\\\\\&quot;},{\\\\\&quot;loadAddress\\\\\&quot;:7197302878,\\\\\&quot;imageName\\\\\&quot;:\\\\\&quot;\\\\/System\\\\/Library\\\\/PrivateFrameworks\\\\/UIKitCore.framework\\\\/UIKitCore\\\\\&quot;,\\\\\&quot;loadEndAddress\\\\\&quot;:7215018077,\\\\\&quot;uuid\\\\\&quot;:\\\\\&quot;005CFA34-6E6A-3F36-BA96-E3DB92F09362\\\\\&quot;}],\\\\\&quot;crash_reason\\\\\&quot;:\\\\\&quot;***-[__NSArrayIobjectAtIndexedSubscript:]:index4beyondbounds[0..1]\\\\\&quot;}&quot;);
}else{
	vars.put(&quot;CRASH_DATA&quot;,&quot;&quot;);
}</stringProp>
            <stringProp name="BeanShellSampler.filename"></stringProp>
            <stringProp name="BeanShellSampler.parameters"></stringProp>
            <boolProp name="BeanShellSampler.resetInterpreter">false</boolProp>
          </BeanShellSampler>
          <hashTree/>
          <ConfigTestElement guiclass="HttpDefaultsGui" testclass="ConfigTestElement" testname="HTTP请求默认值" enabled="true">
            <elementProp name="HTTPsampler.Arguments" elementType="Arguments" guiclass="HTTPArgumentsPanel" testclass="Arguments" testname="用户定义的变量" enabled="true">
              <collectionProp name="Arguments.arguments"/>
            </elementProp>
            <stringProp name="HTTPSampler.domain">${XWFX_IP}</stringProp>
            <stringProp name="HTTPSampler.port">${XWFX_PORT}</stringProp>
            <stringProp name="HTTPSampler.protocol"></stringProp>
            <stringProp name="HTTPSampler.contentEncoding">utf-8</stringProp>
            <stringProp name="HTTPSampler.path"></stringProp>
            <stringProp name="HTTPSampler.concurrentPool">6</stringProp>
            <stringProp name="HTTPSampler.connect_timeout">10000</stringProp>
            <stringProp name="HTTPSampler.response_timeout">20000</stringProp>
          </ConfigTestElement>
          <hashTree/>
          <HeaderManager guiclass="HeaderPanel" testclass="HeaderManager" testname="HTTP信息头管理器" enabled="true">
            <collectionProp name="HeaderManager.headers">
              <elementProp name="" elementType="Header">
                <stringProp name="Header.name">Content-Type</stringProp>
                <stringProp name="Header.value">application/json; charset=utf-8</stringProp>
              </elementProp>
              <elementProp name="" elementType="Header">
                <stringProp name="Header.name">cpv</stringProp>
                <stringProp name="Header.value">aU9TfDEzfDEuMC4wfGExY2FmNGU1NDFiZjYyOThjYTU0ZWM0ODlhZWM3NzA0fDEuMA</stringProp>
              </elementProp>
            </collectionProp>
          </HeaderManager>
          <hashTree/>
          <CookieManager guiclass="CookiePanel" testclass="CookieManager" testname="HTTP Cookie 管理器" enabled="true">
            <collectionProp name="CookieManager.cookies"/>
            <boolProp name="CookieManager.clearEachIteration">false</boolProp>
            <boolProp name="CookieManager.controlledByThreadGroup">false</boolProp>
          </CookieManager>
          <hashTree/>
          <HTTPSamplerProxy guiclass="HttpTestSampleGui" testclass="HTTPSamplerProxy" testname="应用启动埋点" enabled="true">
            <boolProp name="HTTPSampler.postBodyRaw">true</boolProp>
            <elementProp name="HTTPsampler.Arguments" elementType="Arguments">
              <collectionProp name="Arguments.arguments">
                <elementProp name="" elementType="HTTPArgument">
                  <boolProp name="HTTPArgument.always_encode">false</boolProp>
                  <stringProp name="Argument.value">[{&#xd;
	&quot;appcode&quot;: &quot;${APP_CODE}&quot;,&#xd;
	&quot;etime&quot;: ${__time(,)},&#xd;
	&quot;eproperty&quot;: {&#xd;
		&quot;$emethod&quot;: &quot;$startup&quot;,&#xd;
		&quot;$is_first_time&quot;: true&#xd;
	},&#xd;
	&quot;uid&quot;: &quot;${UID}&quot;,&#xd;
	&quot;dproperty&quot;: {&#xd;
		&quot;$session_id&quot;: &quot;${SESSION_ID}&quot;,&#xd;
		&quot;$platform&quot;: &quot;${PLATFORM}&quot;,&#xd;
		&quot;$time_zone&quot;: &quot;GMT+08:00&quot;,&#xd;
		&quot;$screen_width&quot;: ${SCREEN_WIDTH},&#xd;
		&quot;$app_version&quot;: &quot;${APP_VERSION}&quot;,&#xd;
		&quot;$is_first_day&quot;: ${IS_FIRST_DAY},&#xd;
		&quot;$model&quot;: &quot;${MODEL}&quot;,&#xd;
		&quot;$device_id&quot;: &quot;${DEVICE_ID}&quot;,&#xd;
		&quot;$language&quot;: &quot;zh-Hans&quot;,&#xd;
		&quot;$debug&quot;: 2,&#xd;
		&quot;$is_time_calibrated&quot;: false,&#xd;
		&quot;$channel&quot;: &quot;${CHANNEL}&quot;,&#xd;
		&quot;$sdk&quot;: &quot;${SDK}&quot;,&#xd;
		&quot;$sdk_version&quot;: &quot;${SDK_VERSION}&quot;,&#xd;
		&quot;$network&quot;: &quot;${NETWORK}&quot;,&#xd;
		&quot;$brand&quot;: &quot;${BRAND}&quot;,&#xd;
		&quot;$screen_height&quot;: ${SCREEN_HEIGHT},&#xd;
		&quot;$is_login&quot;: false,&#xd;
		&quot;$manufacturer&quot;: &quot;${MANUFACTURER}&quot;,&#xd;
		&quot;$os_version&quot;: &quot;${OS_VERSION}&quot;,&#xd;
		&quot;$os&quot;: &quot;${OS}&quot;,&#xd;
		&quot;$carrier_name&quot;:&quot;${CARRIER_NAME}&quot;,&#xd;
		&quot;$country&quot;:&quot;${COUNTRY}&quot;,&#xd;
		&quot;$province&quot;:&quot;${PROVINCE}&quot;,&#xd;
		&quot;$city&quot;:&quot;${CITY}&quot;&#xd;
	}&#xd;
}]</stringProp>
                  <stringProp name="Argument.metadata">=</stringProp>
                </elementProp>
              </collectionProp>
            </elementProp>
            <stringProp name="HTTPSampler.domain"></stringProp>
            <stringProp name="HTTPSampler.port"></stringProp>
            <stringProp name="HTTPSampler.protocol">http</stringProp>
            <stringProp name="HTTPSampler.contentEncoding">utf-8</stringProp>
            <stringProp name="HTTPSampler.path">/admin/event/record</stringProp>
            <stringProp name="HTTPSampler.method">POST</stringProp>
            <boolProp name="HTTPSampler.follow_redirects">true</boolProp>
            <boolProp name="HTTPSampler.auto_redirects">false</boolProp>
            <boolProp name="HTTPSampler.use_keepalive">true</boolProp>
            <boolProp name="HTTPSampler.DO_MULTIPART_POST">false</boolProp>
            <stringProp name="HTTPSampler.embedded_url_re"></stringProp>
            <stringProp name="HTTPSampler.connect_timeout">20000</stringProp>
            <stringProp name="HTTPSampler.response_timeout">200000</stringProp>
          </HTTPSamplerProxy>
          <hashTree/>
          <HTTPSamplerProxy guiclass="HttpTestSampleGui" testclass="HTTPSamplerProxy" testname="profile_set_once埋点" enabled="false">
            <boolProp name="HTTPSampler.postBodyRaw">true</boolProp>
            <elementProp name="HTTPsampler.Arguments" elementType="Arguments">
              <collectionProp name="Arguments.arguments">
                <elementProp name="" elementType="HTTPArgument">
                  <boolProp name="HTTPArgument.always_encode">false</boolProp>
                  <stringProp name="Argument.value">[{&#xd;
	&quot;appcode&quot;: &quot;${APP_CODE}&quot;,&#xd;
	&quot;etime&quot;: ${__time(,)},&#xd;
	&quot;eproperty&quot;: {&#xd;
		&quot;$emethod&quot;: &quot;$profile_set_once&quot;&#xd;
	},&#xd;
	&quot;uid&quot;: &quot;${UID}&quot;,&#xd;
	&quot;dproperty&quot;: {&#xd;
		&quot;$idfa&quot;: &quot;${IDFA}&quot;,&#xd;
		&quot;$is_login&quot;: false,&#xd;
		&quot;$platform&quot;: &quot;${PLATFORM}&quot;,&#xd;
		&quot;$idfv&quot;: &quot;${IDFV}&quot;,&#xd;
		&quot;$device_id&quot;: &quot;${DEVICE_ID}&quot;,&#xd;
		&quot;$sdk&quot;: &quot;${SDK}&quot;,&#xd;
		&quot;$time_zone&quot;: &quot;GMT+08:00&quot;,&#xd;
		&quot;$first_visit_time&quot;: &quot;${__time(yyyy-MM-dd HH:mm:ss.SSS,)}&quot;,&#xd;
		&quot;$first_visit_language&quot;: &quot;zh-Hans&quot;,&#xd;
		&quot;$sdk_version&quot;: &quot;${SDK_VERSION}&quot;&#xd;
	}&#xd;
}]</stringProp>
                  <stringProp name="Argument.metadata">=</stringProp>
                </elementProp>
              </collectionProp>
            </elementProp>
            <stringProp name="HTTPSampler.domain"></stringProp>
            <stringProp name="HTTPSampler.port"></stringProp>
            <stringProp name="HTTPSampler.protocol">http</stringProp>
            <stringProp name="HTTPSampler.contentEncoding">utf-8</stringProp>
            <stringProp name="HTTPSampler.path">/admin/event/record</stringProp>
            <stringProp name="HTTPSampler.method">POST</stringProp>
            <boolProp name="HTTPSampler.follow_redirects">true</boolProp>
            <boolProp name="HTTPSampler.auto_redirects">false</boolProp>
            <boolProp name="HTTPSampler.use_keepalive">true</boolProp>
            <boolProp name="HTTPSampler.DO_MULTIPART_POST">false</boolProp>
            <stringProp name="HTTPSampler.embedded_url_re"></stringProp>
            <stringProp name="HTTPSampler.connect_timeout">20000</stringProp>
            <stringProp name="HTTPSampler.response_timeout">20000</stringProp>
          </HTTPSamplerProxy>
          <hashTree/>
          <HTTPSamplerProxy guiclass="HttpTestSampleGui" testclass="HTTPSamplerProxy" testname="first_installation埋点" enabled="false">
            <boolProp name="HTTPSampler.postBodyRaw">true</boolProp>
            <elementProp name="HTTPsampler.Arguments" elementType="Arguments">
              <collectionProp name="Arguments.arguments">
                <elementProp name="" elementType="HTTPArgument">
                  <boolProp name="HTTPArgument.always_encode">false</boolProp>
                  <stringProp name="Argument.value">[{&#xd;
	&quot;appcode&quot;: &quot;${APP_CODE}&quot;,&#xd;
	&quot;etime&quot;: ${__time(,)},&#xd;
	&quot;eproperty&quot;: {&#xd;
		&quot;$emethod&quot;: &quot;$first_installation&quot;&#xd;
	},&#xd;
	&quot;uid&quot;: &quot;${UID}&quot;,&#xd;
	&quot;dproperty&quot;: {&#xd;
		&quot;$session_id&quot;: &quot;${SESSION_ID}&quot;,&#xd;
		&quot;$platform&quot;: &quot;${PLATFORM}&quot;,&#xd;
		&quot;$time_zone&quot;: &quot;GMT+08:00&quot;,&#xd;
		&quot;$screen_width&quot;: ${SCREEN_WIDTH},&#xd;
		&quot;$app_version&quot;: &quot;${APP_VERSION}&quot;,&#xd;
		&quot;$is_first_day&quot;: ${IS_FIRST_DAY},&#xd;
		&quot;$model&quot;: &quot;${MODEL}&quot;,&#xd;
		&quot;$device_id&quot;: &quot;${DEVICE_ID}&quot;,&#xd;
		&quot;$language&quot;: &quot;zh-Hans&quot;,&#xd;
		&quot;$debug&quot;: 2,&#xd;
		&quot;$is_time_calibrated&quot;: false,&#xd;
		&quot;$channel&quot;: &quot;${CHANNEL}&quot;,&#xd;
		&quot;$sdk&quot;: &quot;${SDK}&quot;,&#xd;
		&quot;$sdk_version&quot;: &quot;${SDK_VERSION}&quot;,&#xd;
		&quot;$network&quot;: &quot;${NETWORK}&quot;,&#xd;
		&quot;$brand&quot;: &quot;${BRAND}&quot;,&#xd;
		&quot;$screen_height&quot;: ${SCREEN_HEIGHT},&#xd;
		&quot;$is_login&quot;: false,&#xd;
		&quot;$manufacturer&quot;: &quot;${MANUFACTURER}&quot;,&#xd;
		&quot;$os_version&quot;: &quot;${OS_VERSION}&quot;,&#xd;
		&quot;$os&quot;: &quot;${OS}&quot;,&#xd;
		&quot;$carrier_name&quot;:&quot;${CARRIER_NAME}&quot;,&#xd;
		&quot;$country&quot;:&quot;${COUNTRY}&quot;,&#xd;
		&quot;$province&quot;:&quot;${PROVINCE}&quot;,&#xd;
		&quot;$city&quot;:&quot;${CITY}&quot;&#xd;
	}&#xd;
}]</stringProp>
                  <stringProp name="Argument.metadata">=</stringProp>
                </elementProp>
              </collectionProp>
            </elementProp>
            <stringProp name="HTTPSampler.domain"></stringProp>
            <stringProp name="HTTPSampler.port"></stringProp>
            <stringProp name="HTTPSampler.protocol">http</stringProp>
            <stringProp name="HTTPSampler.contentEncoding">utf-8</stringProp>
            <stringProp name="HTTPSampler.path">/admin/event/record</stringProp>
            <stringProp name="HTTPSampler.method">POST</stringProp>
            <boolProp name="HTTPSampler.follow_redirects">true</boolProp>
            <boolProp name="HTTPSampler.auto_redirects">false</boolProp>
            <boolProp name="HTTPSampler.use_keepalive">true</boolProp>
            <boolProp name="HTTPSampler.DO_MULTIPART_POST">false</boolProp>
            <stringProp name="HTTPSampler.embedded_url_re"></stringProp>
            <stringProp name="HTTPSampler.connect_timeout">20000</stringProp>
            <stringProp name="HTTPSampler.response_timeout">20000</stringProp>
          </HTTPSamplerProxy>
          <hashTree/>
          <HTTPSamplerProxy guiclass="HttpTestSampleGui" testclass="HTTPSamplerProxy" testname="应用启动结束埋点" enabled="true">
            <boolProp name="HTTPSampler.postBodyRaw">true</boolProp>
            <elementProp name="HTTPsampler.Arguments" elementType="Arguments">
              <collectionProp name="Arguments.arguments">
                <elementProp name="" elementType="HTTPArgument">
                  <boolProp name="HTTPArgument.always_encode">false</boolProp>
                  <stringProp name="Argument.value">[{&#xd;
	&quot;appcode&quot;: &quot;${APP_CODE}&quot;,&#xd;
	&quot;etime&quot;: ${__time(,)},&#xd;
	&quot;eproperty&quot;: {&#xd;
		&quot;$duration&quot;: ${STARTUP_FINISH_DUR},&#xd;
		&quot;$emethod&quot;: &quot;$startup_finish&quot;&#xd;
	},&#xd;
	&quot;uid&quot;: &quot;${UID}&quot;,&#xd;
	&quot;dproperty&quot;: {&#xd;
		&quot;$session_id&quot;: &quot;${SESSION_ID}&quot;,&#xd;
		&quot;$platform&quot;: &quot;${PLATFORM}&quot;,&#xd;
		&quot;$time_zone&quot;: &quot;GMT+08:00&quot;,&#xd;
		&quot;$screen_width&quot;: ${SCREEN_WIDTH},&#xd;
		&quot;$app_version&quot;: &quot;${APP_VERSION}&quot;,&#xd;
		&quot;$is_first_day&quot;: ${IS_FIRST_DAY},&#xd;
		&quot;$model&quot;: &quot;${MODEL}&quot;,&#xd;
		&quot;$device_id&quot;: &quot;${DEVICE_ID}&quot;,&#xd;
		&quot;$language&quot;: &quot;zh-Hans&quot;,&#xd;
		&quot;$debug&quot;: 2,&#xd;
		&quot;$is_time_calibrated&quot;: false,&#xd;
		&quot;$channel&quot;: &quot;${CHANNEL}&quot;,&#xd;
		&quot;$sdk&quot;: &quot;${SDK}&quot;,&#xd;
		&quot;$sdk_version&quot;: &quot;${SDK_VERSION}&quot;,&#xd;
		&quot;$network&quot;: &quot;${NETWORK}&quot;,&#xd;
		&quot;$brand&quot;: &quot;${BRAND}&quot;,&#xd;
		&quot;$screen_height&quot;: ${SCREEN_HEIGHT},&#xd;
		&quot;$is_login&quot;: false,&#xd;
		&quot;$manufacturer&quot;: &quot;${MANUFACTURER}&quot;,&#xd;
		&quot;$os_version&quot;: &quot;${OS_VERSION}&quot;,&#xd;
		&quot;$os&quot;: &quot;${OS}&quot;,&#xd;
		&quot;$carrier_name&quot;:&quot;${CARRIER_NAME}&quot;,&#xd;
		&quot;$country&quot;:&quot;${COUNTRY}&quot;,&#xd;
		&quot;$province&quot;:&quot;${PROVINCE}&quot;,&#xd;
		&quot;$city&quot;:&quot;${CITY}&quot;&#xd;
	}&#xd;
}]</stringProp>
                  <stringProp name="Argument.metadata">=</stringProp>
                </elementProp>
              </collectionProp>
            </elementProp>
            <stringProp name="HTTPSampler.domain"></stringProp>
            <stringProp name="HTTPSampler.port"></stringProp>
            <stringProp name="HTTPSampler.protocol">http</stringProp>
            <stringProp name="HTTPSampler.contentEncoding">utf-8</stringProp>
            <stringProp name="HTTPSampler.path">/admin/event/record</stringProp>
            <stringProp name="HTTPSampler.method">POST</stringProp>
            <boolProp name="HTTPSampler.follow_redirects">true</boolProp>
            <boolProp name="HTTPSampler.auto_redirects">false</boolProp>
            <boolProp name="HTTPSampler.use_keepalive">true</boolProp>
            <boolProp name="HTTPSampler.DO_MULTIPART_POST">false</boolProp>
            <stringProp name="HTTPSampler.embedded_url_re"></stringProp>
            <stringProp name="HTTPSampler.connect_timeout">20000</stringProp>
            <stringProp name="HTTPSampler.response_timeout">200000</stringProp>
          </HTTPSamplerProxy>
          <hashTree/>
          <BeanShellSampler guiclass="BeanShellSamplerGui" testclass="BeanShellSampler" testname="打开页面变量定义" enabled="true">
            <stringProp name="BeanShellSampler.query">vars.put(&quot;PAGE_VIEW_URL&quot;,&quot;${__RandomString(5,ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz,)}&quot;);
vars.put(&quot;PAGE_VIEW_TITLE&quot;,&quot;测试页面${__RandomString(5,1234567890,)}&quot;);
vars.putObject(&quot;PAGE_VIEW_DUR&quot;,${__Random(500,10000,)});
vars.putObject(&quot;PAGE_CUSTOM_TYPE&quot;,${__Random(0,5,)});</stringProp>
            <stringProp name="BeanShellSampler.filename"></stringProp>
            <stringProp name="BeanShellSampler.parameters"></stringProp>
            <boolProp name="BeanShellSampler.resetInterpreter">false</boolProp>
          </BeanShellSampler>
          <hashTree/>
          <HTTPSamplerProxy guiclass="HttpTestSampleGui" testclass="HTTPSamplerProxy" testname="打开页面埋点" enabled="true">
            <boolProp name="HTTPSampler.postBodyRaw">true</boolProp>
            <elementProp name="HTTPsampler.Arguments" elementType="Arguments">
              <collectionProp name="Arguments.arguments">
                <elementProp name="" elementType="HTTPArgument">
                  <boolProp name="HTTPArgument.always_encode">false</boolProp>
                  <stringProp name="Argument.value">[{&#xd;
	&quot;appcode&quot;: &quot;${APP_CODE}&quot;,&#xd;
	&quot;etime&quot;: ${__time(,)},&#xd;
	&quot;eproperty&quot;: {&#xd;
		&quot;$url&quot;: &quot;${PAGE_VIEW_URL}&quot;,&#xd;
		&quot;$emethod&quot;: &quot;$pageview&quot;,&#xd;
		&quot;$title&quot;: &quot;${PAGE_VIEW_TITLE}&quot;,&#xd;
		&quot;$custom_type&quot;: &quot;${PAGE_CUSTOM_TYPE}&quot;&#xd;
	},&#xd;
	&quot;uid&quot;: &quot;${UID}&quot;,&#xd;
	&quot;dproperty&quot;: {&#xd;
		&quot;$session_id&quot;: &quot;${SESSION_ID}&quot;,&#xd;
		&quot;$platform&quot;: &quot;${PLATFORM}&quot;,&#xd;
		&quot;$time_zone&quot;: &quot;GMT+08:00&quot;,&#xd;
		&quot;$screen_width&quot;: ${SCREEN_WIDTH},&#xd;
		&quot;$app_version&quot;: &quot;${APP_VERSION}&quot;,&#xd;
		&quot;$is_first_day&quot;: ${IS_FIRST_DAY},&#xd;
		&quot;$model&quot;: &quot;${MODEL}&quot;,&#xd;
		&quot;$device_id&quot;: &quot;${DEVICE_ID}&quot;,&#xd;
		&quot;$language&quot;: &quot;zh-Hans&quot;,&#xd;
		&quot;$debug&quot;: 2,&#xd;
		&quot;$is_time_calibrated&quot;: false,&#xd;
		&quot;$channel&quot;: &quot;${CHANNEL}&quot;,&#xd;
		&quot;$sdk&quot;: &quot;${SDK}&quot;,&#xd;
		&quot;$sdk_version&quot;: &quot;${SDK_VERSION}&quot;,&#xd;
		&quot;$network&quot;: &quot;${NETWORK}&quot;,&#xd;
		&quot;$brand&quot;: &quot;${BRAND}&quot;,&#xd;
		&quot;$screen_height&quot;: ${SCREEN_HEIGHT},&#xd;
		&quot;$is_login&quot;: false,&#xd;
		&quot;$manufacturer&quot;: &quot;${MANUFACTURER}&quot;,&#xd;
		&quot;$os_version&quot;: &quot;${OS_VERSION}&quot;,&#xd;
		&quot;$os&quot;: &quot;${OS}&quot;,&#xd;
		&quot;$carrier_name&quot;:&quot;${CARRIER_NAME}&quot;,&#xd;
		&quot;$country&quot;:&quot;${COUNTRY}&quot;,&#xd;
		&quot;$province&quot;:&quot;${PROVINCE}&quot;,&#xd;
		&quot;$city&quot;:&quot;${CITY}&quot;&#xd;
	}&#xd;
}]</stringProp>
                  <stringProp name="Argument.metadata">=</stringProp>
                </elementProp>
              </collectionProp>
            </elementProp>
            <stringProp name="HTTPSampler.domain"></stringProp>
            <stringProp name="HTTPSampler.port"></stringProp>
            <stringProp name="HTTPSampler.protocol">http</stringProp>
            <stringProp name="HTTPSampler.contentEncoding">utf-8</stringProp>
            <stringProp name="HTTPSampler.path">/admin/event/record</stringProp>
            <stringProp name="HTTPSampler.method">POST</stringProp>
            <boolProp name="HTTPSampler.follow_redirects">true</boolProp>
            <boolProp name="HTTPSampler.auto_redirects">false</boolProp>
            <boolProp name="HTTPSampler.use_keepalive">true</boolProp>
            <boolProp name="HTTPSampler.DO_MULTIPART_POST">false</boolProp>
            <stringProp name="HTTPSampler.embedded_url_re"></stringProp>
            <stringProp name="HTTPSampler.connect_timeout">20000</stringProp>
            <stringProp name="HTTPSampler.response_timeout">200000</stringProp>
          </HTTPSamplerProxy>
          <hashTree/>
          <HTTPSamplerProxy guiclass="HttpTestSampleGui" testclass="HTTPSamplerProxy" testname="打开页面结束埋点" enabled="true">
            <boolProp name="HTTPSampler.postBodyRaw">true</boolProp>
            <elementProp name="HTTPsampler.Arguments" elementType="Arguments">
              <collectionProp name="Arguments.arguments">
                <elementProp name="" elementType="HTTPArgument">
                  <boolProp name="HTTPArgument.always_encode">false</boolProp>
                  <stringProp name="Argument.value">[{&#xd;
	&quot;appcode&quot;: &quot;${APP_CODE}&quot;,&#xd;
	&quot;etime&quot;: ${__time(,)},&#xd;
	&quot;eproperty&quot;: {&#xd;
		&quot;$page_dur&quot;: ${PAGE_VIEW_DUR},&#xd;
		&quot;$emethod&quot;: &quot;$pageview_leave&quot;,&#xd;
		&quot;$title&quot;: &quot;${PAGE_VIEW_TITLE}&quot;,&#xd;
		&quot;$url&quot;: &quot;${PAGE_VIEW_URL}&quot;,&#xd;
	},&#xd;
	&quot;uid&quot;: &quot;${UID}&quot;,&#xd;
	&quot;dproperty&quot;: {&#xd;
		&quot;$session_id&quot;: &quot;${SESSION_ID}&quot;,&#xd;
		&quot;$platform&quot;: &quot;${PLATFORM}&quot;,&#xd;
		&quot;$time_zone&quot;: &quot;GMT+08:00&quot;,&#xd;
		&quot;$screen_width&quot;: ${SCREEN_WIDTH},&#xd;
		&quot;$app_version&quot;: &quot;${APP_VERSION}&quot;,&#xd;
		&quot;$is_first_day&quot;: ${IS_FIRST_DAY},&#xd;
		&quot;$model&quot;: &quot;${MODEL}&quot;,&#xd;
		&quot;$device_id&quot;: &quot;${DEVICE_ID}&quot;,&#xd;
		&quot;$language&quot;: &quot;zh-Hans&quot;,&#xd;
		&quot;$debug&quot;: 2,&#xd;
		&quot;$is_time_calibrated&quot;: false,&#xd;
		&quot;$channel&quot;: &quot;${CHANNEL}&quot;,&#xd;
		&quot;$sdk&quot;: &quot;${SDK}&quot;,&#xd;
		&quot;$sdk_version&quot;: &quot;${SDK_VERSION}&quot;,&#xd;
		&quot;$network&quot;: &quot;${NETWORK}&quot;,&#xd;
		&quot;$brand&quot;: &quot;${BRAND}&quot;,&#xd;
		&quot;$screen_height&quot;: ${SCREEN_HEIGHT},&#xd;
		&quot;$is_login&quot;: false,&#xd;
		&quot;$manufacturer&quot;: &quot;${MANUFACTURER}&quot;,&#xd;
		&quot;$os_version&quot;: &quot;${OS_VERSION}&quot;,&#xd;
		&quot;$os&quot;: &quot;${OS}&quot;,&#xd;
		&quot;$carrier_name&quot;:&quot;${CARRIER_NAME}&quot;,&#xd;
		&quot;$country&quot;:&quot;${COUNTRY}&quot;,&#xd;
		&quot;$province&quot;:&quot;${PROVINCE}&quot;,&#xd;
		&quot;$city&quot;:&quot;${CITY}&quot;&#xd;
	}&#xd;
}]</stringProp>
                  <stringProp name="Argument.metadata">=</stringProp>
                </elementProp>
              </collectionProp>
            </elementProp>
            <stringProp name="HTTPSampler.domain"></stringProp>
            <stringProp name="HTTPSampler.port"></stringProp>
            <stringProp name="HTTPSampler.protocol">http</stringProp>
            <stringProp name="HTTPSampler.contentEncoding">utf-8</stringProp>
            <stringProp name="HTTPSampler.path">/admin/event/record</stringProp>
            <stringProp name="HTTPSampler.method">POST</stringProp>
            <boolProp name="HTTPSampler.follow_redirects">true</boolProp>
            <boolProp name="HTTPSampler.auto_redirects">false</boolProp>
            <boolProp name="HTTPSampler.use_keepalive">true</boolProp>
            <boolProp name="HTTPSampler.DO_MULTIPART_POST">false</boolProp>
            <stringProp name="HTTPSampler.embedded_url_re"></stringProp>
            <stringProp name="HTTPSampler.connect_timeout">20000</stringProp>
            <stringProp name="HTTPSampler.response_timeout">200000</stringProp>
          </HTTPSamplerProxy>
          <hashTree/>
          <BeanShellSampler guiclass="BeanShellSamplerGui" testclass="BeanShellSampler" testname="交易请求变量定义" enabled="true">
            <stringProp name="BeanShellSampler.query">vars.put(&quot;EXCHANGE_HOST&quot;,&quot;10.${__Random(1,255,)}.${__Random(1,255,)}.${__Random(1,255,)}&quot;);
vars.put(&quot;EXCHANGE_URL&quot;,&quot;/pweb/test${__RandomString(6,1234567890,)}&quot;);
vars.putObject(&quot;STATUS_CODE&quot;,${__RandomFromMultipleVars(STATUS_CODE_value1|STATUS_CODE_value2|STATUS_CODE_value3|STATUS_CODE_value4,)});
vars.putObject(&quot;REQ_DUR&quot;,${__Random(500,1000,)});</stringProp>
            <stringProp name="BeanShellSampler.filename"></stringProp>
            <stringProp name="BeanShellSampler.parameters"></stringProp>
            <boolProp name="BeanShellSampler.resetInterpreter">false</boolProp>
          </BeanShellSampler>
          <hashTree/>
          <HTTPSamplerProxy guiclass="HttpTestSampleGui" testclass="HTTPSamplerProxy" testname="交易请求埋点" enabled="true">
            <boolProp name="HTTPSampler.postBodyRaw">true</boolProp>
            <elementProp name="HTTPsampler.Arguments" elementType="Arguments">
              <collectionProp name="Arguments.arguments">
                <elementProp name="" elementType="HTTPArgument">
                  <boolProp name="HTTPArgument.always_encode">false</boolProp>
                  <stringProp name="Argument.value">[{&#xd;
	&quot;appcode&quot;: &quot;${APP_CODE}&quot;,&#xd;
	&quot;etime&quot;: ${__time(,)},&#xd;
	&quot;eproperty&quot;: {&#xd;
		&quot;$emethod&quot;: &quot;$msg_exchange&quot;,&#xd;
		&quot;$host&quot;: &quot;${EXCHANGE_HOST}&quot;,&#xd;
		&quot;$url&quot;: &quot;${EXCHANGE_URL}&quot;,&#xd;
		&quot;$status_code&quot;: &quot;${STATUS_CODE}&quot;,&#xd;
		&quot;$req_dur&quot;: &quot;${REQ_DUR}&quot;&#xd;
	},&#xd;
	&quot;uid&quot;: &quot;${UID}&quot;,&#xd;
	&quot;dproperty&quot;: {&#xd;
		&quot;$session_id&quot;: &quot;${SESSION_ID}&quot;,&#xd;
		&quot;$platform&quot;: &quot;${PLATFORM}&quot;,&#xd;
		&quot;$time_zone&quot;: &quot;GMT+08:00&quot;,&#xd;
		&quot;$screen_width&quot;: ${SCREEN_WIDTH},&#xd;
		&quot;$app_version&quot;: &quot;${APP_VERSION}&quot;,&#xd;
		&quot;$is_first_day&quot;: ${IS_FIRST_DAY},&#xd;
		&quot;$model&quot;: &quot;${MODEL}&quot;,&#xd;
		&quot;$device_id&quot;: &quot;${DEVICE_ID}&quot;,&#xd;
		&quot;$language&quot;: &quot;zh-Hans&quot;,&#xd;
		&quot;$debug&quot;: 2,&#xd;
		&quot;$is_time_calibrated&quot;: false,&#xd;
		&quot;$channel&quot;: &quot;${CHANNEL}&quot;,&#xd;
		&quot;$sdk&quot;: &quot;${SDK}&quot;,&#xd;
		&quot;$sdk_version&quot;: &quot;${SDK_VERSION}&quot;,&#xd;
		&quot;$network&quot;: &quot;${NETWORK}&quot;,&#xd;
		&quot;$brand&quot;: &quot;${BRAND}&quot;,&#xd;
		&quot;$screen_height&quot;: ${SCREEN_HEIGHT},&#xd;
		&quot;$is_login&quot;: false,&#xd;
		&quot;$manufacturer&quot;: &quot;${MANUFACTURER}&quot;,&#xd;
		&quot;$os_version&quot;: &quot;${OS_VERSION}&quot;,&#xd;
		&quot;$os&quot;: &quot;${OS}&quot;,&#xd;
		&quot;$carrier_name&quot;:&quot;${CARRIER_NAME}&quot;,&#xd;
		&quot;$country&quot;:&quot;${COUNTRY}&quot;,&#xd;
		&quot;$province&quot;:&quot;${PROVINCE}&quot;,&#xd;
		&quot;$city&quot;:&quot;${CITY}&quot;&#xd;
	}&#xd;
}]</stringProp>
                  <stringProp name="Argument.metadata">=</stringProp>
                </elementProp>
              </collectionProp>
            </elementProp>
            <stringProp name="HTTPSampler.domain"></stringProp>
            <stringProp name="HTTPSampler.port"></stringProp>
            <stringProp name="HTTPSampler.protocol">http</stringProp>
            <stringProp name="HTTPSampler.contentEncoding">utf-8</stringProp>
            <stringProp name="HTTPSampler.path">/admin/event/record</stringProp>
            <stringProp name="HTTPSampler.method">POST</stringProp>
            <boolProp name="HTTPSampler.follow_redirects">true</boolProp>
            <boolProp name="HTTPSampler.auto_redirects">false</boolProp>
            <boolProp name="HTTPSampler.use_keepalive">true</boolProp>
            <boolProp name="HTTPSampler.DO_MULTIPART_POST">false</boolProp>
            <stringProp name="HTTPSampler.embedded_url_re"></stringProp>
            <stringProp name="HTTPSampler.connect_timeout">20000</stringProp>
            <stringProp name="HTTPSampler.response_timeout">200000</stringProp>
          </HTTPSamplerProxy>
          <hashTree/>
          <HTTPSamplerProxy guiclass="HttpTestSampleGui" testclass="HTTPSamplerProxy" testname="crash埋点" enabled="true">
            <boolProp name="HTTPSampler.postBodyRaw">true</boolProp>
            <elementProp name="HTTPsampler.Arguments" elementType="Arguments">
              <collectionProp name="Arguments.arguments">
                <elementProp name="" elementType="HTTPArgument">
                  <boolProp name="HTTPArgument.always_encode">false</boolProp>
                  <stringProp name="Argument.value">[{&#xd;
	&quot;appcode&quot;: &quot;${APP_CODE}&quot;,&#xd;
	&quot;etime&quot;: ${__time(,)},&#xd;
	&quot;eproperty&quot;: {&#xd;
		&quot;$emethod&quot;: &quot;$app_crash&quot;,&#xd;
		&quot;$crash_data&quot;: &quot;${CRASH_DATA}&quot;&#xd;
	},&#xd;
	&quot;uid&quot;: &quot;${UID}&quot;,&#xd;
	&quot;dproperty&quot;: {&#xd;
		&quot;$session_id&quot;: &quot;${SESSION_ID}&quot;,&#xd;
		&quot;$platform&quot;: &quot;${PLATFORM}&quot;,&#xd;
		&quot;$time_zone&quot;: &quot;GMT+08:00&quot;,&#xd;
		&quot;$screen_width&quot;: ${SCREEN_WIDTH},&#xd;
		&quot;$app_version&quot;: &quot;${APP_VERSION}&quot;,&#xd;
		&quot;$is_first_day&quot;: ${IS_FIRST_DAY},&#xd;
		&quot;$model&quot;: &quot;${MODEL}&quot;,&#xd;
		&quot;$device_id&quot;: &quot;${DEVICE_ID}&quot;,&#xd;
		&quot;$language&quot;: &quot;zh-Hans&quot;,&#xd;
		&quot;$debug&quot;: 2,&#xd;
		&quot;$is_time_calibrated&quot;: false,&#xd;
		&quot;$channel&quot;: &quot;${CHANNEL}&quot;,&#xd;
		&quot;$sdk&quot;: &quot;${SDK}&quot;,&#xd;
		&quot;$sdk_version&quot;: &quot;${SDK_VERSION}&quot;,&#xd;
		&quot;$network&quot;: &quot;${NETWORK}&quot;,&#xd;
		&quot;$brand&quot;: &quot;${BRAND}&quot;,&#xd;
		&quot;$screen_height&quot;: ${SCREEN_HEIGHT},&#xd;
		&quot;$is_login&quot;: false,&#xd;
		&quot;$manufacturer&quot;: &quot;${MANUFACTURER}&quot;,&#xd;
		&quot;$os_version&quot;: &quot;${OS_VERSION}&quot;,&#xd;
		&quot;$os&quot;: &quot;${OS}&quot;,&#xd;
		&quot;$carrier_name&quot;:&quot;${CARRIER_NAME}&quot;,&#xd;
		&quot;$country&quot;:&quot;${COUNTRY}&quot;,&#xd;
		&quot;$province&quot;:&quot;${PROVINCE}&quot;,&#xd;
		&quot;$city&quot;:&quot;${CITY}&quot;&#xd;
	}&#xd;
}]</stringProp>
                  <stringProp name="Argument.metadata">=</stringProp>
                </elementProp>
              </collectionProp>
            </elementProp>
            <stringProp name="HTTPSampler.domain"></stringProp>
            <stringProp name="HTTPSampler.port"></stringProp>
            <stringProp name="HTTPSampler.protocol">http</stringProp>
            <stringProp name="HTTPSampler.contentEncoding">utf-8</stringProp>
            <stringProp name="HTTPSampler.path">/admin/event/record</stringProp>
            <stringProp name="HTTPSampler.method">POST</stringProp>
            <boolProp name="HTTPSampler.follow_redirects">true</boolProp>
            <boolProp name="HTTPSampler.auto_redirects">false</boolProp>
            <boolProp name="HTTPSampler.use_keepalive">true</boolProp>
            <boolProp name="HTTPSampler.DO_MULTIPART_POST">false</boolProp>
            <stringProp name="HTTPSampler.embedded_url_re"></stringProp>
            <stringProp name="HTTPSampler.connect_timeout">20000</stringProp>
            <stringProp name="HTTPSampler.response_timeout">200000</stringProp>
          </HTTPSamplerProxy>
          <hashTree/>
          <HTTPSamplerProxy guiclass="HttpTestSampleGui" testclass="HTTPSamplerProxy" testname="白屏" enabled="true">
            <boolProp name="HTTPSampler.postBodyRaw">true</boolProp>
            <elementProp name="HTTPsampler.Arguments" elementType="Arguments">
              <collectionProp name="Arguments.arguments">
                <elementProp name="" elementType="HTTPArgument">
                  <boolProp name="HTTPArgument.always_encode">false</boolProp>
                  <stringProp name="Argument.value">[{&#xd;
	&quot;appcode&quot;: &quot;${APP_CODE}&quot;,&#xd;
	&quot;etime&quot;: ${__time(,)},&#xd;
	&quot;eproperty&quot;: {&#xd;
		&quot;$referrer&quot;: &quot;ssss&quot;,&#xd;
		&quot;$emethod&quot;: &quot;$check_white&quot;,&#xd;
		&quot;$img&quot;: &quot;/9j/4AAQSkZJRgABAQEAeAB4AAD/4QBaRXhpZgAATU0AKgAAAAgABQMBAAUAAAABAAAASgMDAAEAAAABAAAAAFEQAAEAAAABAQAAAFERAAQAAAABAAASdFESAAQAAAABAAASdAAAAAAAAYagAACxj//bAEMACAYGBwYFCAcHBwkJCAoMFA0MCwsMGRITDxQdGh8eHRocHCAkLicgIiwjHBwoNyksMDE0NDQfJzk9ODI8LjM0Mv/bAEMBCQkJDAsMGA0NGDIhHCEyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMv/AABEIAHIArQMBIgACEQEDEQH/xAAfAAABBQEBAQEBAQAAAAAAAAAAAQIDBAUGBwgJCgv/xAC1EAACAQMDAgQDBQUEBAAAAX0BAgMABBEFEiExQQYTUWEHInEUMoGRoQgjQrHBFVLR8CQzYnKCCQoWFxgZGiUmJygpKjQ1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4eLj5OXm5+jp6vHy8/T19vf4+fr/xAAfAQADAQEBAQEBAQEBAAAAAAAAAQIDBAUGBwgJCgv/xAC1EQACAQIEBAMEBwUEBAABAncAAQIDEQQFITEGEkFRB2FxEyIygQgUQpGhscEJIzNS8BVictEKFiQ04SXxFxgZGiYnKCkqNTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqCg4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2dri4+Tl5ufo6ery8/T19vf4+fr/2gAMAwEAAhEDEQA/APf6KKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAI/Pi/wCeqf8AfQo8+L/nqn/fQqKigCXz4v8Anqn/AH0KPPi/56p/30KiooAl8+L/AJ6p/wB9Cjz4v+eqf99CoqKAJfPi/wCeqf8AfQo8+L/nqn/fQqKigCXz4v8Anqn/AH0KPPi/56p/30KiooAl8+L/AJ6p/wB9Cjz4v+eqf99CoqKAJfPi/wCeqf8AfQo8+L/nqn/fQqKigCXz4v8Anqn/AH0KPPi/56p/30KiooAl8+L/AJ6p/wB9Cjz4v+eqf99CoqKAJfPi/wCeqf8AfQo8+L/nqn/fQqKigCXz4v8Anqn/AH0KPPi/56p/30KiooAXyf8Apo/6f4UeT/00f9P8KlopDIvJ/wCmj/p/hR5P/TR/0/wqWigCLyf+mj/p/hR5P/TR/wBP8KlooAi8n/po/wCn+FHk/wDTR/0/wqWigCLyf+mj/p/hR5P/AE0f9P8ACpaKAIvJ/wCmj/p/hR5P/TR/0/wqWigCLyf+mj/p/hR5P/TR/wBP8KlooAi8n/po/wCn+FHk/wDTR/0/wqWigCLyf+mj/p/hR5P/AE0f9P8ACpaKAIvJ/wCmj/p/hR5P/TR/0/wqWigCLyf+mj/p/hR5P/TR/wBP8KlooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD//Z&quot;,&#xd;
		&quot;$url&quot;: &quot;sssss&quot;&#xd;
	},&#xd;
	&quot;uid&quot;: &quot;${UID}&quot;,&#xd;
	&quot;dproperty&quot;: {&#xd;
		&quot;$session_id&quot;: &quot;${SESSION_ID}&quot;,&#xd;
		&quot;$platform&quot;: &quot;${PLATFORM}&quot;,&#xd;
		&quot;$time_zone&quot;: &quot;GMT+08:00&quot;,&#xd;
		&quot;$screen_width&quot;: ${SCREEN_WIDTH},&#xd;
		&quot;$app_version&quot;: &quot;${APP_VERSION}&quot;,&#xd;
		&quot;$is_first_day&quot;: ${IS_FIRST_DAY},&#xd;
		&quot;$model&quot;: &quot;${MODEL}&quot;,&#xd;
		&quot;$device_id&quot;: &quot;${DEVICE_ID}&quot;,&#xd;
		&quot;$language&quot;: &quot;zh-Hans&quot;,&#xd;
		&quot;$debug&quot;: 2,&#xd;
		&quot;$is_time_calibrated&quot;: false,&#xd;
		&quot;$channel&quot;: &quot;${CHANNEL}&quot;,&#xd;
		&quot;$sdk&quot;: &quot;${SDK}&quot;,&#xd;
		&quot;$sdk_version&quot;: &quot;${SDK_VERSION}&quot;,&#xd;
		&quot;$network&quot;: &quot;${NETWORK}&quot;,&#xd;
		&quot;$brand&quot;: &quot;${BRAND}&quot;,&#xd;
		&quot;$screen_height&quot;: ${SCREEN_HEIGHT},&#xd;
		&quot;$is_login&quot;: false,&#xd;
		&quot;$manufacturer&quot;: &quot;${MANUFACTURER}&quot;,&#xd;
		&quot;$os_version&quot;: &quot;${OS_VERSION}&quot;,&#xd;
		&quot;$os&quot;: &quot;${OS}&quot;,&#xd;
		&quot;$carrier_name&quot;:&quot;${CARRIER_NAME}&quot;,&#xd;
		&quot;$country&quot;:&quot;${COUNTRY}&quot;,&#xd;
		&quot;$province&quot;:&quot;${PROVINCE}&quot;,&#xd;
		&quot;$city&quot;:&quot;${CITY}&quot;&#xd;
	}&#xd;
}]</stringProp>
                  <stringProp name="Argument.metadata">=</stringProp>
                </elementProp>
              </collectionProp>
            </elementProp>
            <stringProp name="HTTPSampler.domain"></stringProp>
            <stringProp name="HTTPSampler.port"></stringProp>
            <stringProp name="HTTPSampler.protocol">http</stringProp>
            <stringProp name="HTTPSampler.contentEncoding">utf-8</stringProp>
            <stringProp name="HTTPSampler.path">/admin/event/record</stringProp>
            <stringProp name="HTTPSampler.method">POST</stringProp>
            <boolProp name="HTTPSampler.follow_redirects">true</boolProp>
            <boolProp name="HTTPSampler.auto_redirects">false</boolProp>
            <boolProp name="HTTPSampler.use_keepalive">true</boolProp>
            <boolProp name="HTTPSampler.DO_MULTIPART_POST">false</boolProp>
            <stringProp name="HTTPSampler.embedded_url_re"></stringProp>
            <stringProp name="HTTPSampler.connect_timeout">20000</stringProp>
            <stringProp name="HTTPSampler.response_timeout">200000</stringProp>
          </HTTPSamplerProxy>
          <hashTree/>
          <HTTPSamplerProxy guiclass="HttpTestSampleGui" testclass="HTTPSamplerProxy" testname="应用结束埋点" enabled="true">
            <boolProp name="HTTPSampler.postBodyRaw">true</boolProp>
            <elementProp name="HTTPsampler.Arguments" elementType="Arguments">
              <collectionProp name="Arguments.arguments">
                <elementProp name="" elementType="HTTPArgument">
                  <boolProp name="HTTPArgument.always_encode">false</boolProp>
                  <stringProp name="Argument.value">[{&#xd;
	&quot;appcode&quot;: &quot;${APP_CODE}&quot;,&#xd;
	&quot;etime&quot;: ${__time(,)},&#xd;
	&quot;eproperty&quot;: {&#xd;
		&quot;$duration&quot;: ${END_DUR},&#xd;
		&quot;$emethod&quot;: &quot;$end&quot;&#xd;
	},&#xd;
	&quot;uid&quot;: &quot;${UID}&quot;,&#xd;
	&quot;dproperty&quot;: {&#xd;
		&quot;$session_id&quot;: &quot;${SESSION_ID}&quot;,&#xd;
		&quot;$platform&quot;: &quot;${PLATFORM}&quot;,&#xd;
		&quot;$time_zone&quot;: &quot;GMT+08:00&quot;,&#xd;
		&quot;$screen_width&quot;: ${SCREEN_WIDTH},&#xd;
		&quot;$app_version&quot;: &quot;${APP_VERSION}&quot;,&#xd;
		&quot;$is_first_day&quot;: ${IS_FIRST_DAY},&#xd;
		&quot;$model&quot;: &quot;${MODEL}&quot;,&#xd;
		&quot;$device_id&quot;: &quot;${DEVICE_ID}&quot;,&#xd;
		&quot;$language&quot;: &quot;zh-Hans&quot;,&#xd;
		&quot;$debug&quot;: 2,&#xd;
		&quot;$is_time_calibrated&quot;: false,&#xd;
		&quot;$channel&quot;: &quot;${CHANNEL}&quot;,&#xd;
		&quot;$sdk&quot;: &quot;${SDK}&quot;,&#xd;
		&quot;$sdk_version&quot;: &quot;${SDK_VERSION}&quot;,&#xd;
		&quot;$network&quot;: &quot;${NETWORK}&quot;,&#xd;
		&quot;$brand&quot;: &quot;${BRAND}&quot;,&#xd;
		&quot;$screen_height&quot;: ${SCREEN_HEIGHT},&#xd;
		&quot;$is_login&quot;: false,&#xd;
		&quot;$manufacturer&quot;: &quot;${MANUFACTURER}&quot;,&#xd;
		&quot;$os_version&quot;: &quot;${OS_VERSION}&quot;,&#xd;
		&quot;$os&quot;: &quot;${OS}&quot;,&#xd;
		&quot;$carrier_name&quot;:&quot;${CARRIER_NAME}&quot;,&#xd;
		&quot;$country&quot;:&quot;${COUNTRY}&quot;,&#xd;
		&quot;$province&quot;:&quot;${PROVINCE}&quot;,&#xd;
		&quot;$city&quot;:&quot;${CITY}&quot;&#xd;
	}&#xd;
}]</stringProp>
                  <stringProp name="Argument.metadata">=</stringProp>
                </elementProp>
              </collectionProp>
            </elementProp>
            <stringProp name="HTTPSampler.domain"></stringProp>
            <stringProp name="HTTPSampler.port"></stringProp>
            <stringProp name="HTTPSampler.protocol">http</stringProp>
            <stringProp name="HTTPSampler.contentEncoding">utf-8</stringProp>
            <stringProp name="HTTPSampler.path">/admin/event/record</stringProp>
            <stringProp name="HTTPSampler.method">POST</stringProp>
            <boolProp name="HTTPSampler.follow_redirects">true</boolProp>
            <boolProp name="HTTPSampler.auto_redirects">false</boolProp>
            <boolProp name="HTTPSampler.use_keepalive">true</boolProp>
            <boolProp name="HTTPSampler.DO_MULTIPART_POST">false</boolProp>
            <stringProp name="HTTPSampler.embedded_url_re"></stringProp>
            <stringProp name="HTTPSampler.connect_timeout">20000</stringProp>
            <stringProp name="HTTPSampler.response_timeout">200000</stringProp>
          </HTTPSamplerProxy>
          <hashTree/>
        </hashTree>
        <ResultCollector guiclass="ViewResultsFullVisualizer" testclass="ResultCollector" testname="察看结果树" enabled="true">
          <boolProp name="ResultCollector.error_logging">false</boolProp>
          <objProp>
            <name>saveConfig</name>
            <value class="SampleSaveConfiguration">
              <time>true</time>
              <latency>true</latency>
              <timestamp>true</timestamp>
              <success>true</success>
              <label>true</label>
              <code>true</code>
              <message>true</message>
              <threadName>true</threadName>
              <dataType>true</dataType>
              <encoding>false</encoding>
              <assertions>true</assertions>
              <subresults>true</subresults>
              <responseData>true</responseData>
              <samplerData>true</samplerData>
              <xml>true</xml>
              <fieldNames>true</fieldNames>
              <responseHeaders>true</responseHeaders>
              <requestHeaders>true</requestHeaders>
              <responseDataOnError>true</responseDataOnError>
              <saveAssertionResultsFailureMessage>true</saveAssertionResultsFailureMessage>
              <assertionsResultsToSave>0</assertionsResultsToSave>
              <bytes>true</bytes>
              <sentBytes>true</sentBytes>
              <url>true</url>
              <threadCounts>true</threadCounts>
              <idleTime>true</idleTime>
              <connectTime>true</connectTime>
            </value>
          </objProp>
          <stringProp name="filename"></stringProp>
        </ResultCollector>
        <hashTree/>
        <ResultCollector guiclass="StatVisualizer" testclass="ResultCollector" testname="聚合报告" enabled="true">
          <boolProp name="ResultCollector.error_logging">false</boolProp>
          <objProp>
            <name>saveConfig</name>
            <value class="SampleSaveConfiguration">
              <time>true</time>
              <latency>true</latency>
              <timestamp>true</timestamp>
              <success>true</success>
              <label>true</label>
              <code>true</code>
              <message>true</message>
              <threadName>true</threadName>
              <dataType>true</dataType>
              <encoding>false</encoding>
              <assertions>true</assertions>
              <subresults>true</subresults>
              <responseData>false</responseData>
              <samplerData>false</samplerData>
              <xml>false</xml>
              <fieldNames>true</fieldNames>
              <responseHeaders>false</responseHeaders>
              <requestHeaders>false</requestHeaders>
              <responseDataOnError>false</responseDataOnError>
              <saveAssertionResultsFailureMessage>true</saveAssertionResultsFailureMessage>
              <assertionsResultsToSave>0</assertionsResultsToSave>
              <bytes>true</bytes>
              <sentBytes>true</sentBytes>
              <url>true</url>
              <threadCounts>true</threadCounts>
              <idleTime>true</idleTime>
              <connectTime>true</connectTime>
            </value>
          </objProp>
          <stringProp name="filename"></stringProp>
        </ResultCollector>
        <hashTree/>
      </hashTree>
    </hashTree>
  </hashTree>
</jmeterTestPlan>
